package com.example.razmik_midterm2.ApiData

import com.example.razmik_midterm2.Details.Entries
import retrofit2.http.GET

interface NameApiService {
    @GET("names")
    suspend fun getNames(): List<Entries>
}