package com.example.razmik_midterm2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import com.example.razmik_midterm2.ApiData.NameApiService
import com.example.razmik_midterm2.ApiData.RetrofitHelper
import com.example.razmik_midterm2.Details.Entries
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.create
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val namesAPIResults = RetrofitHelper.getInstance().create(NameApiService::class.java)

        GlobalScope.launch {
            val result = namesAPIResults.getNames()
        }
        //actual loading of composable via viewmodel unifnished
    }

    //method for UI
    @Composable
    fun LazyNameColumn(namesListToGet: List<Entries>) {
        LazyColumn {
            items(namesListToGet) {
                entry -> entryCard(entry)
            }
        }
    }

    //unfinished
    @Composable
    fun entryCard(entry: Entries) {

    }
}
