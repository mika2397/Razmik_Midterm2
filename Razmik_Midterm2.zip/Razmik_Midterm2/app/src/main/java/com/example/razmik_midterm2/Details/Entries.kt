package com.example.razmik_midterm2.Details

import com.google.gson.annotations.SerializedName

data class Entries(
    @SerializedName("results")
    var results: List<DetailResponse>?
)

class DetailResponse(
    @SerializedName("name")
    var name: List<NameResponse>?,
    @SerializedName("email")
    var email: String?,
    @SerializedName("nat")
    var nat: String?
    )

class NameResponse(
    @SerializedName("first")
    var first: String?,
    @SerializedName("last")
    var last: String?
)
